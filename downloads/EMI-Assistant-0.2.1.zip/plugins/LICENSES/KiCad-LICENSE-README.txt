The majority of KiCad's source code is developed and distributed under the terms
of the GPLv3 or later. However, it does include some third-party code licensed
under other licenses (see below for details).

These licenses are compatible, but a combined works as is will be governed under
the terms of the GPLv3 (or later). This includes any binary distribution of the
KiCad EDA suite by the KiCad project or any third party, e.g. Linux distributor.

You are free to use the *sources* under the terms of their respective licenses.

Licensed under Apache License, Version 2.0
 - portions of code in libs/kimath/include/math/util.h
Licensed under BOOSTv1:
- clipper in thirdparty/clipper
- clipper2 in thirdparty/clipper2
- libcontext [https://github.com/boostorg/context] in thirdparty/libcontext
- pegtl in thirdparty/pegtl
- picosha2 in thirdparty/picosha2
- turtle in thirdparty/turtle
Licensed under ISC:
- portions of code in include/geometry/polygon_triangulation.h
Licensed under MIT:
- argparse in thirdparty/argparse
- compoundfilereader in thirdparty/compoundfilereader
- delaunator in thirdparty/delaunator
- fmt in thirdparty/fmt
- glad in thirdparty/glad
- json_schema_validator in thirdparty/json_schema_validator
- magic_enum in thirdparty/magic_enum
- nanodbc in thirdparty/nanodbc
- nlohmann/json in thirdparty/nlohmann_json
- nlohmann/fifo_map in thirdparty/nlohmann_json
- pboettch/json-schema-validator in thirdparty/json_schema_validator
- picoSHA2 in thirdparty/picosha2
- rectpack2d in thirdparty/rectpack2d
- sentry-native in thirdparty/sentry-native
- thread-pool in thirdparty/thread-pool
- tinyspline_lib in thirdparty/tinyspline_lib
Licensed under BSD:
- pybind11 in thirdparty/pybind11
Licensed under BSD2:
- gzip-hpp in thirdparty/gzip-hpp
Licensed under GPLv2 (or later):
- dxflib in thirdparty/dxflib_qcad
- math_for_graphics in thirdparty/other_math
- potrace in thirdparty/potrace
- SutherlandHodgmanClipPoly in thirdparty/other_math
Licensed under ZLib:
- nanosvg in thirdparty/nanosvg
Licensed in the public domain:
- lemon in thirdparty/lemon
Licensed under CC BY-SA 4.0:
- All the demo files provided in demos/*
Licensed under clause-3 BSD:
- ibis / kibis files in eeschema/sim/kibis
Licensed under CC0:
- uopamp.lib.spice in some directories in qa/data/eeschema/spice_netlists/
Licensed under GPLv3 (or later):
- All remaining code not listed above
